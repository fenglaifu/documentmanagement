<template>
    <div>
        <div v-html="vHtml" />
    </div>
</template>

<script>
/* import { mammoth } from 'mammoth'; */
/* import {convertToHtml} from "mammoth"; */
import axios from "axios";
export default {
    name: 'Word',
    setup(){
        let vHtml = '11';
        
        /* mammoth.convertToHtml({path: "/public/11.doc"})
        .then(result => {
            vHtml = result.value; // The generated HTML
            var messages = result.messages; // Any messages, such as warnings during conversion
        })
        .done(); */

        return {
            vHtml
        }
    }
}

</script>

<style scoped>

</style>