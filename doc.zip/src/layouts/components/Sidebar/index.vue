<template>
<el-aside :width="store.state.sideBarWidth" class="menuleft">
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <el-menu
        :default-active="activeMenu"
        :background-color="variables.menuBg"
        :text-color="variables.menuText"
        :unique-opened="false"
        :active-text-color="variables.menuActiveText"
        mode="vertical"
      >
        <sidebar-item
          v-for="route in routes"
          :key="route.path"
          :item="route"
          :base-path="route.path"
        />
      </el-menu>
    </el-scrollbar>
    <div class="toggleButton" @click="togleCollapse">
      <i class="el-icon-caret-left" style="height: 50px;width: 50px;"></i>
    </div>
</el-aside>  
</template>

<script setup>
import store from '../../../../src/store'
import SidebarItem from "./SidebarItem.vue";
import { computed, ref,reactive } from "vue";
import { useRoute } from "vue-router";
import { routes } from "/@/router";
import variables from "styles/variables.module.scss";

const activeMenu = computed(() => {
  const route = useRoute();
  const { meta, path } = route;
  if (meta.activeMenu) {
    return meta.activeMenu;
  }
  return path;
});
// let statte = reactive({isCollapse: false});
let isCollapse = ref(false);
const togleCollapse = () =>{
  console.log('togleCollapse')
  console.log(store)
    //  statte.isCollapse = !statte.isCollapse;
    isCollapse.value = !isCollapse.value;
     console.log('togleCollapse')
     if(isCollapse.value){
       store.state.sideBarWidth = '60px';
     }
     else{
       store.state.sideBarWidth = store.state.defSideBarWidth;
     }
}
</script>
<style scoped>
  .menuleft{
    width: 210px;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .toggleButton{
    font-size: 14px;
  }
</style>
