import {createStore} from 'vuex'

const store = createStore({
    state: {
      counter: 0,
      sideBarWidth : '210px',
      defSideBarWidth : '210px'
    },
  });
  
export default store;