<template>
    <div>
        <Designer v-on:designerInitialized="designerInitialized"></Designer>
    </div>
</template>

<script>
import Designer from '../../components/Designer.vue'
import {ref} from "vue"
import axios from "axios"
import GC from '@grapecity/spread-sheets'
import ExcelIO from '@grapecity/spread-excelio'
export default {
    name: 'DesignerView',
    components: {
        Designer
    },
    setup() {
        let designer = undefined;
        let designerInitialized=(wb)=>{
            designer = wb;
            let workbook = designer.getWorkbook();
            const service = axios.create({
            baseURL: "http://localhost:4000",
            timeout: 5000
        });
        service.get('/users/getFile').then(result => {
            console.log(result)
            let blob = new Blob([result.data], { type: "application/octet-stream" });
            let excelIO = new GC.Spread.Excel.IO();
            let excelFile = '/public/OA系统人员信息.xls';
            excelIO.open(blob, function (json) {
                var workbookObj = json;
                workbook.fromJSON(workbookObj);
            }, function (e) {
                console.log(e);
            });
            
        }).catch(error => {
            console.log("error")
            console.log(error)
        })
            /* let excelIO = new GC.Spread.Excel.IO();
            let excelFile = '/public/OA系统人员信息.xls';
            excelIO.open(excelFile, function (json) {
                var workbookObj = json;
                workbook.fromJSON(workbookObj);
            }, function (e) {
                console.log(e);
            }); */
        }
        /** */
/* let update = (e)=>{
        let spread = designer.getWorkbook();
        let spreadJSON = JSON.stringify(spread.toJSON());
        let formData = new FormData();
        formData.append("jsonString", spreadJSON);
        formData.append("fileName", "fileName");
        axios.post('spread/updateTemplate', formData).then((response) => {
            if(response) {
                alert("更新成功");
            }
        }).catch((response) => {
            alert("错误");
        })
    }
let load = (e)=>{
        let spread = designer.getWorkbook();
        let formData = new FormData();
        formData.append("fileName", "path");
        axios.post('spread/loadTemplate', formData, {
            responseType: "json",
        }).then((response) => {
            if(response) {
                alert("加载成功");
                templateJSON = response.data;
                spread.fromJSON(templateJSON);
            }
        }).catch((response) => {
            alert("错误");
        })
    }
        
let ribbonFileCommands = {
        "loadTemplateCommand": {
            iconClass: "ribbon-button-download",
            text: "加载",
            //bigButton: true,
            commandName: "loadTemplate",
            execute: load
        },
        "updateTemplateCommand": {
            iconClass: "ribbon-button-upload",
            text: "更新",
            //bigButton: true,
            commandName: "updateTemplate",
            execute: update
        }
    };

let customerRibbon = {
      id: "operate",
      text: "操作",
      buttonGroups: [
        {
          label: "文件操作",
          thumbnailClass: "ribbon-thumbnail-spreadsettings",
          commandGroup: {
            children: [
              {
                direction: "vertical",
                commands: ["loadTemplateCommand", "updateTemplateCommand"],
              }
            ],
          },
        },
      ],
    }; */
/* let DefaultConfig = GC.Spread.Sheets.Designer.DefaultConfig;
DefaultConfig.fileMenu= null; */
/* 删除默认选项卡 */
/* DefaultConfig.ribbon.splice(0, DefaultConfig.ribbon.length + 1);

DefaultConfig.ribbon.push(customerRibbon);
    DefaultConfig.commandMap = {};
    Object.assign(DefaultConfig.commandMap, ribbonFileCommands);  */
/** */
console.log(GC.Spread.Sheets.Designer.DefaultConfig)
        return {designerInitialized}
    }
}
</script>

<style scoped>

</style>