<template>
    <div>
        工作通知详情
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>