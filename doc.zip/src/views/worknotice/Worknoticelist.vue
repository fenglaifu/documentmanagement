<template>
    <div class="app-container">
       <!-- <pdf-component></pdf-component> -->
       <designer-view></designer-view>
       <!-- <word></word> -->
    </div>
</template>

<script lang="ts">
import { toRefs } from "vue";
import { useRouter } from "vue-router";
import Pagination from '../../../src/components/Pagination.vue';
import PdfComponent from '../../../src/components/PdfComponent.vue';
import Word from '../../../src/components/Word.vue';
import DesignerView from '../SpreadSheet/DesignerView.vue';
/* import { WorkNoticeModelData } from './model/worknoticeModel'; */
export default {
  name: "Worknoticelist",
  components: {
    Pagination,
    PdfComponent,
    DesignerView,
    Word
  },
  setup() {
    console.log('import.meta.env')
    console.log(import.meta.env)
    const router = useRouter();
    /* const {state, getDataList} = WorkNoticeModelData();

    // 查看详情
    function handleView({row}) {
      router.push({
        name: "noticeDetail",
        params: { id: row.id },
      });
    }

    return {
      ...toRefs(state),
      handleView,
      getDataList
    }; */
  },
};
</script>

<style scoped>

</style>