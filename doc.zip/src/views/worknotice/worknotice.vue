<template>
    <div class="app-container">
        <router-view></router-view>
    </div>
    
</template>

<script setup lang="ts">
</script>

<style scoped>

</style>