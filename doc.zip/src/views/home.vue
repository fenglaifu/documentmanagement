<template>
    <div>
        <el-row :gutter="12">
            <el-col :span="8">
                <el-card shadow="always">
                <router-link to="/worknotice/worknoticelist">工作通知</router-link>
                </el-card>
            </el-col>
            <!-- <el-col :span="8">
                <el-card shadow="always">
                <router-link to="/doc/doclist">文档</router-link>
                </el-card>
            </el-col> -->
        </el-row>
        
        <!-- <pdf-component></pdf-component> -->
        <router-view></router-view>
    </div>
</template>

<script lang="ts">
/* import PdfComponent from '../../src/components/PdfComponent'; */
export default {
  name: "home",
  /* components: {
    PdfComponent,
  } */
}
</script>

<style scoped>

</style>