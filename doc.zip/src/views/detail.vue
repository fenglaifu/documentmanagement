<template>
  <div>
    detail <span>{{$route.params.id}}</span>
  </div>
</template>

<script setup>
  
</script>

<style scoped>

</style>