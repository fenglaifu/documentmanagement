<template>
  <detail :is-edit="true"></detail>
</template>

<script>
import Detail from "./components/detail.vue";

export default {
  components: {
    Detail,
  },
};
</script>
