package com.doc.management.constant;

public class Constant {

	public static String separator = "/";//File.separator
}
